import os
import torch
import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from torch.utils.data import DataLoader
from src.dataset import PTBXLDataset
from src.model import ECG_CNN

DATA_PATH = "D:/um/7023/brench dataset/ptb-xl-a-large-publicly-available-electrocardiography-dataset-1.0.3/"
LABEL_CSV = os.path.join(DATA_PATH, "ptbxl_database.csv")
MODEL_PATH = "models/cnn_model_71.pth"

def evaluate_model(data_path, label_path, model_path):
    # 加载测试集
    test_dataset = PTBXLDataset(data_path, label_path, train=False)
    test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

    # 加载模型
    model = ECG_CNN(num_classes=test_dataset.num_classes)
    model.load_state_dict(torch.load(model_path))
    model.eval()
    model.to("cuda" if torch.cuda.is_available() else "cpu")

    y_true, y_pred = [], []

    with torch.no_grad():
        for inputs, labels in test_loader:
            inputs = inputs.to("cuda" if torch.cuda.is_available() else "cpu")
            outputs = model(inputs).cpu()

            y_true.extend(labels.numpy())
            y_pred.extend((outputs > 0.5).int().numpy())

    # 转换为 DataFrame
    df_true = pd.DataFrame(y_true, columns=[f"True_{cls}" for cls in test_dataset.classes])
    df_pred = pd.DataFrame(y_pred, columns=[f"Pred_{cls}" for cls in test_dataset.classes])
    df_out = pd.concat([df_true, df_pred], axis=1)

    # 保存输出
    df_out.to_csv("results/cnn_predictions.csv", index=False)
    print("✅ Predictions saved to results/cnn_predictions.csv")

    # 多标签平均指标
    y_true_tensor = torch.tensor(y_true)
    y_pred_tensor = torch.tensor(y_pred)
    accuracy = (y_true_tensor == y_pred_tensor).float().mean().item()
    precision = precision_score(y_true, y_pred, average='macro', zero_division=0)
    recall = recall_score(y_true, y_pred, average='macro', zero_division=0)
    f1 = f1_score(y_true, y_pred, average='macro', zero_division=0)

    print("\n📊 Evaluation Results:")
    print(f"Accuracy:  {accuracy:.4f}")
    print(f"Precision: {precision:.4f}")
    print(f"Recall:    {recall:.4f}")
    print(f"F1 Score:  {f1:.4f}")

if __name__ == "__main__":
    os.makedirs("results", exist_ok=True)
    evaluate_model(DATA_PATH, LABEL_CSV, MODEL_PATH)
